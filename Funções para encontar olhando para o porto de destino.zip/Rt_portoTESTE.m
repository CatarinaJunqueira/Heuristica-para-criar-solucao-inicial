


function [MovGeral,Navio,lista_descarregamento] = Rt_portoTESTE(patio,navio,RegraRetirada,Navio,RegraCarregamento,porto,lista_descarregamento)
%tic;
MovGeral=0;
% id_navio = unique(navio); % identifica quais s�o os navios de destino e os coloca em ordem crescente
% k=length(id_navio); %vou rodar a regra para a quantidade de navios existentes
% DistanciaTotal=0;
%     for i=1:k

%     %--------------------------------------------------------------------------%
%     % identificando a regra que vai ser utilizada (qual localiza e qual vazio) % 
%     localiza = strcat('encontra',int2str(RegraRetirada)); % caso olhando apenas para o navio de destino
      localiza = strcat('encontra_porto',int2str(RegraRetirada)); % caso olhando para o navio e para o porto de destino de cada cont�iner
      vzio = strcat('desguarnecido',int2str(RegraRetirada));
%     %--------------------------------------------------------------------------%

      [l_navio] = feval(localiza,porto,patio,navio,1); % CASO  RETIRANDO OLHANDO O PORTO DE DESTINO!!!!
%     [l_navio] = feval(localiza,patio,navio,1); % CASO RETIRANDO OLHANDO APENAS O NAVIO!!!!
      % Chamando o localiza, traz uma lista das posi��es dos cont�ineres que v�o ser retirados.
%     % id_navio=1 � porque vou retirar os cont�ineres do navio 1. Pode ser
%     % de outro navio, ou de todos, conforme est� na regra
%     % Rt_descarregamento


k=unique(l_navio(:,3));
k=flipud(k);
h=cell(length(k),1);
% for j=1:length(k)
%     
    [row,~]=(find(l_navio(:,3)==k(1)));
    T(1)=length(find(l_navio(:,3)==k(1)));
%     if j==1
        h{1}=l_navio(1:row(end),1:2);
     %   u=row(end);
%     else
%        h{j}=l_navio(u+1:row(end),1:2);
%        u=row(end);
%     end
%     
% end




for j=1:length(k)
   %[mov_total,~,Navio,lista_descarregamento] = mover_porto(patio,l_navio,vzio,Navio,RegraCarregamento,porto,lista_descarregamento);
    l_navio=h{j};
    [mov_total,patio,Navio,lista_descarregamento] = mover1(patio,l_navio,vzio,Navio,RegraCarregamento,porto,lista_descarregamento);
   %[mov_total,~,Distancia,Navio] = mover1(patio,l_navio,vzio,Navio,RegraCarregamento);
    MovGeral=MovGeral+mov_total;
   % DistanciaTotal=DistanciaTotal+Distancia;
   [l_navio] = feval(localiza,porto,patio,navio,1);
    if j~=length(k)
       [row,~]=(find(l_navio(:,3)==k(j+1)));
        h{j+1}=l_navio(1:row(end),1:2);    
    end
end

%end
%tempo=toc;
end






