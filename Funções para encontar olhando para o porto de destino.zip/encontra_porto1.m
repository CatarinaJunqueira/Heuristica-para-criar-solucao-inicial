function [posicoes2] = encontra_porto1(porto,patio,navio,id_navio) % localiza posi��o e n�o conte�do.

Y=length(find(navio(1,:)==id_navio)); % encontra os conteineres que vao para o navio id_navio
posicoes=zeros(Y,3);

[linha,coluna]=size(patio);
c_local = 1; % inicializando um contador. 

% Ordem que vai percorrer

    for i = 1:linha %corrigindo a ordem de verifica��o.
         for k = 1:coluna   
             if patio(i,k) ~= 0
                [~,col]=find(navio(2,:)==patio(i,k)); %encontro a coluna desse cont no vetor navio
                 if navio(1,col)==id_navio % se esse cont vai para o navio id_navio                       
                    posicoes(c_local,1) = i; % ent�o coloco na lista
                    posicoes(c_local,2) = k;
                    posicoes(c_local,3) = porto(1,col);
                    c_local = c_local + 1;    % lista de vazios/cont�ineres (posi��o no p�tio)                              
                 end
             end
         end
    end 
    
    NN=unique(porto(1,:));
    NN=fliplr(NN);
    posicoes2=zeros(Y,3);
    c=1;
    u=1;
    while sum(NN)~=0
        for g=1:Y
            if posicoes(g,1)~=0
                if posicoes(g,3)== NN(u);
                   posicoes2(c,:)=posicoes(g,:); 
                    c=c+1;
                end           
            end     
        end 
        NN(1,u)=0;
        u=u+1;
    end
     
  %  posicoes2(:,3)=[];
    
end