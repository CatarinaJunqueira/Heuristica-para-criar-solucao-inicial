function [posicoes2] = encontra_porto4(porto,patio,navio,id_navio) % localiza posi��o e n�o conte�do.

Y=length(find(navio(1,:)==id_navio)); % encontra os conteineres que vao para o navio id_navio
posicoes=zeros(Y,3);

[linha,coluna]=size(patio);
c_local = 1; % inicializando um contador. 

% Ordem que vai percorrer
    for k = coluna:-1:1 %corrigindo a ordem de verifica��o.
         for i = 1:linha   
             if patio(i,k) ~= 0
                [~,col]=find(navio(2,:)==patio(i,k));
                 if navio(1,col)==id_navio
                    posicoes(c_local,1) = i;
                    posicoes(c_local,2) = k;
                    posicoes(c_local,3) = porto(1,col);
                    c_local = c_local + 1;    % lista de vazios/cont�ineres (posi��o no p�tio)                 
                 end
             end
         end
    end 
    
    
    NN=unique(porto(1,:));
    NN=fliplr(NN);
    posicoes2=zeros(Y,3);
    c=1;
    u=1;
    while sum(NN)~=0
        for g=1:Y
            if posicoes(g,1)~=0
                if posicoes(g,3)== NN(u);
                   posicoes2(c,:)=posicoes(g,:); 
                    c=c+1;
                end           
            end     
        end 
        NN(1,u)=0;
        u=u+1;
    end
     
   % posicoes2(:,3)=[];
    
end